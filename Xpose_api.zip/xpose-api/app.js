const axios = require('axios');

// Replace with the email you want to check
const email = "test@example.com";

// XPOSE API endpoint
const apiUrl = `https://api.xposedornot.com/v1/check-email/${email}`;

// Function to check if an email is in any breach
async function checkEmailBreach() {
  try {
    // Make the GET request to the XPOSE API
    const response = await axios.get(apiUrl);

    // Handle and print the API response
    if (response.data.breaches) {
      console.log(`Breaches found for ${email}:`);
      console.log(response.data.breaches[0].join(', '));
    } else if (response.data.Error) {
      console.log(`No breaches found for ${email}: ${response.data.Error}`);
    }
  } catch (error) {
    // Handle errors from the API
    if (error.response) {
      console.error(`Error: ${error.response.status} - ${error.response.data}`);
    } else {
      console.error(`Error: ${error.message}`);
    }
  }
}

// Call the function
checkEmailBreach();
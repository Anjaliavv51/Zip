document.getElementById('breachForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    
    const emailInput = document.getElementById('email').value;

    try {
        const response = await fetch('/checkBreach', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email: emailInput })
        });

        const result = await response.json();
        
        // Display result
        document.getElementById('result').innerText = JSON.stringify(result);
        
    } catch (error) {
        document.getElementById('result').innerText = 'Error checking breach.';
        console.error('Error:', error);
    }
});
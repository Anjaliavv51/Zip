const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const axios = require('axios');

dotenv.config(); // Load environment variables from .env file

const app = express();
const port = process.env.PORT || 5000;

// Middleware to parse JSON bodies
app.use(express.json());

// Serve static files from the public directory
app.use(express.static('public')); // Ensure this line is present

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error('MongoDB connection error:', err));

// Endpoint to check for breaches
app.post('/checkBreach', async (req, res) => {
    const email = req.body.email;

    console.log('Checking breach for email:', email); // Log the email being checked

    try {
        // Call the XPOSE API
        const response = await axios.get(`https://api.xposedornot.com/v1/check-email/${email}`);
        
        // Log the entire response for debugging
        console.log('API Response:', response.data);

        // If breaches are found, return them
        if (response.data.breaches) {
            return res.status(200).json({ breaches: response.data.breaches[0] });
        }

        // If no breaches are found, return a message
        return res.status(200).json({ message: 'No breaches found.' });
    } catch (error) {
        // Log detailed error information
        if (error.response) {
            console.error('Error:', JSON.stringify(error.response.data, null, 2));
            if (error.response.status === 404) {
                return res.status(200).json({ message: 'No breaches found.' });
            }
        } else {
            console.error('Error:', error.message);
        }
        return res.status(500).json({ error: 'An error occurred while checking breaches.' });
    }
});

// Start server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});